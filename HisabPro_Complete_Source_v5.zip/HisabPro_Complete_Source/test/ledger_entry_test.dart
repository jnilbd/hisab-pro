import 'package:flutter_test/flutter_test.dart';
import 'package:hisabpro/models/ledger_entry.dart';

void main() {
  test('ledger entry serializes and restores all core fields', () {
    final original = LedgerEntry(
      uuid: 'test-1', title: 'Rony', person: 'Rony', amount: 25000,
      type: EntryType.debt, date: DateTime(2026, 11, 2),
      note: 'initial debt', category: 'ঋণ',
    );
    final restored = LedgerEntry.fromMap(original.toMap(includeId: false));
    expect(restored.uuid, original.uuid);
    expect(restored.amount, 25000);
    expect(restored.type, EntryType.debt);
    expect(restored.category, 'ঋণ');
  });

  test('outflow classifications are consistent', () {
    expect(EntryType.payment.isOutflow, isTrue);
    expect(EntryType.installment.isOutflow, isTrue);
    expect(EntryType.expense.isOutflow, isTrue);
    expect(EntryType.phonePurchase.isOutflow, isTrue);
    expect(EntryType.income.isOutflow, isFalse);
    expect(EntryType.phoneSale.isOutflow, isFalse);
  });
}
