enum EntryType { debt, payment, loan, installment, income, expense, phonePurchase, phoneSale }
extension EntryTypeX on EntryType {
  String get label => switch(this) { EntryType.debt=>'নতুন ধার', EntryType.payment=>'ধার পরিশোধ', EntryType.loan=>'ঋণ গ্রহণ', EntryType.installment=>'কিস্তি পরিশোধ', EntryType.income=>'আয়', EntryType.expense=>'খরচ', EntryType.phonePurchase=>'মোবাইল ক্রয়', EntryType.phoneSale=>'মোবাইল বিক্রয়' };
  bool get isOutflow => this==EntryType.payment || this==EntryType.installment || this==EntryType.expense || this==EntryType.phonePurchase;
}
class LedgerEntry {
 final int? id; final String uuid; final String title; final String person; final int amount; final EntryType type; final DateTime date; final String note; final String category;
 const LedgerEntry({this.id, required this.uuid, required this.title, this.person='', required this.amount, required this.type, required this.date, this.note='', this.category='General'});
 Map<String,Object?> toMap({bool includeId=true}) => {if(includeId && id!=null) 'id':id,'uuid':uuid,'title':title,'person':person,'amount':amount,'type':type.name,'date':date.toIso8601String(),'note':note,'category':category};
 factory LedgerEntry.fromMap(Map<String,Object?> m)=>LedgerEntry(id:m['id'] as int?,uuid:(m['uuid'] as String?)??'${m['id']}',title:m['title'] as String,person:(m['person'] as String?)??'',amount:(m['amount'] as num).toInt(),type:EntryType.values.firstWhere((e)=>e.name==m['type'],orElse:()=>EntryType.expense),date:DateTime.parse(m['date'] as String),note:(m['note'] as String?)??'',category:(m['category'] as String?)??'General');
}
