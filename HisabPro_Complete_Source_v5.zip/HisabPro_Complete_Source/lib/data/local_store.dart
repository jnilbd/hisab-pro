import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/ledger_entry.dart';

class LocalStore {
  LocalStore._();
  static final instance = LocalStore._();
  Database? _db;
  Future<Database> get db async {
    if (_db != null) return _db!;
    final p = join(await getDatabasesPath(), 'hisabpro.db');
    _db = await openDatabase(p, version: 3,
      onCreate: (d, v) async {
        await d.execute('''CREATE TABLE entries(
          id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT UNIQUE NOT NULL,
          title TEXT NOT NULL, person TEXT NOT NULL DEFAULT '', amount INTEGER NOT NULL CHECK(amount>0),
          type TEXT NOT NULL, date TEXT NOT NULL, note TEXT NOT NULL DEFAULT '',
          category TEXT NOT NULL DEFAULT 'General', synced INTEGER NOT NULL DEFAULT 0,
          deleted INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL)''');
        await d.execute('CREATE INDEX entries_date_idx ON entries(date DESC)');
        await d.execute('CREATE TABLE settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)');
      },
      onUpgrade: (d, old, v) async {
        if (old < 2) {
          final cols = (await d.rawQuery('PRAGMA table_info(entries)')).map((x) => x['name']).toSet();
          if (!cols.contains('uuid')) await d.execute('ALTER TABLE entries ADD COLUMN uuid TEXT');
          if (!cols.contains('category')) await d.execute("ALTER TABLE entries ADD COLUMN category TEXT NOT NULL DEFAULT 'General'");
          if (!cols.contains('synced')) await d.execute('ALTER TABLE entries ADD COLUMN synced INTEGER NOT NULL DEFAULT 0');
          await d.execute("UPDATE entries SET uuid='legacy-' || id WHERE uuid IS NULL OR uuid=''");
        }
        if (old < 3) {
          final cols = (await d.rawQuery('PRAGMA table_info(entries)')).map((x) => x['name']).toSet();
          if (!cols.contains('deleted')) await d.execute('ALTER TABLE entries ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0');
          if (!cols.contains('updated_at')) await d.execute("ALTER TABLE entries ADD COLUMN updated_at TEXT NOT NULL DEFAULT '2000-01-01T00:00:00.000'");
        }
      });
    return _db!;
  }
  Future<List<LedgerEntry>> all({EntryType? type}) async {
    final where = type == null ? 'deleted=0' : 'deleted=0 AND type=?';
    final rows = await (await db).query('entries', where: where, whereArgs: type == null ? null : [type.name], orderBy: 'date DESC,id DESC');
    return rows.map(LedgerEntry.fromMap).toList();
  }
  Future<int> add(LedgerEntry e) async => (await db).insert('entries', {...e.toMap(includeId:false), 'synced':0, 'deleted':0, 'updated_at':DateTime.now().toIso8601String()});
  Future<int> update(LedgerEntry e) async => (await db).update('entries', {...e.toMap(includeId:false), 'synced':0, 'updated_at':DateTime.now().toIso8601String()}, where:'id=?', whereArgs:[e.id]);
  Future<int> delete(int id) async => (await db).update('entries', {'deleted':1,'synced':0,'updated_at':DateTime.now().toIso8601String()}, where:'id=?', whereArgs:[id]);
  Future<void> setSetting(String k,String v) async { await (await db).insert('settings', {'key':k,'value':v}, conflictAlgorithm:ConflictAlgorithm.replace); }
  Future<String?> getSetting(String k) async { final r=await (await db).query('settings',where:'key=?',whereArgs:[k]); return r.isEmpty?null:r.first['value'] as String; }
  Future<void> markSynced(String uuid, {String? expectedUpdatedAt}) async {
    final d = await db;
    await d.update('entries', {'synced': 1}, where: expectedUpdatedAt == null ? 'uuid=?' : 'uuid=? AND updated_at=?', whereArgs: expectedUpdatedAt == null ? [uuid] : [uuid, expectedUpdatedAt]);
  }
  Future<List<Map<String,Object?>>> pending() async => (await db).query('entries',where:'synced=0');
  Future<void> mergeCloud(Map<String,dynamic> row) async {
    final uuid = row['local_id'] as String;
    final d = await db;
    final existing = await d.query('entries', where: 'uuid=?', whereArgs: [uuid], limit: 1);
    final remoteUpdated = (row['updated_at'] as String?) ?? DateTime.now().toIso8601String();
    if (existing.isNotEmpty) {
      final local = existing.first;
      // Never overwrite an unsynced local edit. For already-synced rows, keep
      // whichever complete record has the newest timestamp (last-write-wins).
      if ((local['synced'] as int? ?? 0) == 0) return;
      final localUpdated = local['updated_at'] as String? ?? '';
      final localTime = DateTime.tryParse(localUpdated);
      final remoteTime = DateTime.tryParse(remoteUpdated);
      if (localTime != null && remoteTime != null && !remoteTime.isAfter(localTime)) return;
      await d.update('entries', {
        'title': row['title'], 'person': row['person'] ?? '',
        'amount': row['amount'], 'type': row['type'], 'date': row['entry_date'],
        'note': row['note'] ?? '', 'category': row['category'] ?? 'General',
        'synced': 1, 'deleted': row['deleted_at'] == null ? 0 : 1,
        'updated_at': remoteUpdated,
      }, where: 'uuid=?', whereArgs: [uuid]);
      return;
    }
    await d.insert('entries', {
      'uuid':uuid,'title':row['title'],'person':row['person'] ?? '', 'amount':row['amount'],
      'type':row['type'],'date':row['entry_date'],'note':row['note'] ?? '', 'category':row['category'] ?? 'General',
      'synced':1,'deleted':row['deleted_at'] == null ? 0 : 1,
      'updated_at':remoteUpdated
    }, conflictAlgorithm:ConflictAlgorithm.ignore);
  }

  Future<void> restoreSnapshot(List<Map<String,Object?>> entries, List<Map<String,Object?>> settings) async {
    final d = await db;
    await d.transaction((txn) async {
      await txn.delete('entries');
      await txn.delete('settings');
      for (final source in entries) {
        final row = Map<String,Object?>.from(source);
        row.remove('id');
        // Restored data must be uploaded again to the currently linked account.
        row['synced'] = 0;
        await txn.insert('entries', row, conflictAlgorithm: ConflictAlgorithm.replace);
      }
      for (final row in settings) {
        await txn.insert('settings', row, conflictAlgorithm: ConflictAlgorithm.replace);
      }
    });
  }

  Future<void> replaceFromImport(List<Map<String,Object?>> rows) async {
    final d=await db;
    await d.transaction((txn) async {
      for(final row in rows) {
        final clean={...row,'synced':0,'deleted':0,'updated_at':DateTime.now().toIso8601String()};
        clean.remove('id');
        await txn.insert('entries',clean,conflictAlgorithm:ConflictAlgorithm.replace);
      }
    });
  }
}
