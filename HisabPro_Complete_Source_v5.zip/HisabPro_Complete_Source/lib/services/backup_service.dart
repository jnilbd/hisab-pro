import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../data/local_store.dart';

/// Full local backup including tombstones and app settings.
/// JSON backups are not encrypted: users must store/share them securely.
class BackupService {
  static const format = 'hisabpro-backup';
  static const version = 1;

  static Future<void> exportBackup() async {
    final db = await LocalStore.instance.db;
    final entries = await db.query('entries', orderBy: 'id ASC');
    final settings = await db.query('settings', orderBy: 'key ASC');
    final payload = <String, dynamic>{
      'format': format,
      'version': version,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'currency': 'BDT',
      'entries': entries,
      'settings': settings,
    };
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/hisabpro_backup_${DateTime.now().millisecondsSinceEpoch}.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(payload), flush: true);
    await Share.shareXFiles([XFile(file.path)], text: 'HisabPro পূর্ণাঙ্গ Backup (JSON)');
  }

  /// Restores by replacing local data. Caller must obtain explicit confirmation.
  static Future<int> restoreBackup() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['json'], withData: true);
    if (result == null || result.files.single.bytes == null) return 0;
    final decoded = jsonDecode(utf8.decode(result.files.single.bytes!));
    if (decoded is! Map || decoded['format'] != format || decoded['version'] != version || decoded['entries'] is! List || decoded['settings'] is! List) {
      throw const FormatException('এটি সমর্থিত HisabPro backup ফাইল নয়।');
    }
    final entries = (decoded['entries'] as List).map((e) => Map<String, Object?>.from(e as Map)).toList();
    final settings = (decoded['settings'] as List).map((e) => Map<String, Object?>.from(e as Map)).toList();
    for (final row in entries) {
      if (row['uuid'] is! String || row['title'] is! String || row['amount'] is! int || (row['amount'] as int) <= 0) {
        throw const FormatException('Backup-এ ভুল বা অসম্পূর্ণ হিসাব পাওয়া গেছে।');
      }
    }
    await LocalStore.instance.restoreSnapshot(entries, settings);
    return entries.length;
  }
}
