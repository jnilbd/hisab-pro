import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import '../data/local_store.dart';
import '../models/ledger_entry.dart';

class CloudSync {
  static bool _initialized = false;
  static Future<void> initialize() async {
    if (AppConfig.cloudConfigured && !_initialized) {
      await Supabase.initialize(url: AppConfig.supabaseUrl, anonKey: AppConfig.supabaseAnonKey);
      _initialized = true;
    }
  }
  static bool get available => AppConfig.cloudConfigured && _initialized;
  static SupabaseClient get client => Supabase.instance.client;
  static bool get signedIn => available && client.auth.currentUser != null;
  static Future<int> sync() async {
    if (!available || !signedIn) throw Exception('Cloud backup-এর আগে Supabase-এ sign in করুন।');
    final uid=client.auth.currentUser!.id;
    final localPending=await LocalStore.instance.pending();
    for(final row in localPending) {
      final e=LedgerEntry.fromMap(row);
      final snapshotUpdatedAt = row['updated_at'] as String? ?? DateTime.now().toIso8601String();
      await client.from('ledger_entries').upsert({
        'user_id':uid,'local_id':e.uuid,'title':e.title,'person':e.person,
        'amount':e.amount,'type':e.type.name,'entry_date':e.date.toIso8601String(),
        'note':e.note,'category':e.category,
        'deleted_at':row['deleted']==1 ? DateTime.now().toIso8601String() : null,
        'updated_at':snapshotUpdatedAt,
      }, onConflict:'user_id,local_id');
      await LocalStore.instance.markSynced(e.uuid, expectedUpdatedAt: snapshotUpdatedAt);
    }
    final remote=await client.from('ledger_entries').select().eq('user_id',uid).order('updated_at');
    final pendingIds=localPending.map((e)=>e['uuid']).toSet();
    for(final raw in (remote as List)) {
      final row=Map<String,dynamic>.from(raw as Map);
      if(!pendingIds.contains(row['local_id'])) await LocalStore.instance.mergeCloud(row);
    }
    return localPending.length;
  }
}
