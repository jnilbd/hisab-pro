import 'dart:io';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../data/local_store.dart';

class DataExport {
 static Future<void> exportCsv() async {
   final rows=await LocalStore.instance.all();
   final data=<List<dynamic>>[
     ['uuid','title','person','amount_bdt','type','date','category','note'],
     ...rows.map((e)=>[e.uuid,e.title,e.person,e.amount,e.type.name,e.date.toIso8601String(),e.category,e.note])
   ];
   final csv=const ListToCsvConverter().convert(data);
   final dir=await getTemporaryDirectory();
   final file=File('${dir.path}/hisabpro_export_${DateTime.now().millisecondsSinceEpoch}.csv');
   await file.writeAsString('\uFEFF$csv',flush:true);
   await Share.shareXFiles([XFile(file.path)],text:'HisabPro হিসাব Export');
 }
}
