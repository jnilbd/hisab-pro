import '../data/local_store.dart';
import '../models/ledger_entry.dart';

class InitialDebtSeed {
  static const records = <(String,int,EntryType)>[
    ('Raj',1020,EntryType.debt),('Jahangir',6000,EntryType.debt),('Rony',25000,EntryType.debt),
    ('Sobuj',1500,EntryType.debt),('Mosiur',500,EntryType.debt),('Nasim',1000,EntryType.debt),
    ('Hasibul',1000,EntryType.debt),('Bizu',200,EntryType.debt),('Towfiq vai',12000,EntryType.debt),
    ('Towfiq sir',40000,EntryType.debt),('Basa vara',7800,EntryType.debt),('Bow',15000,EntryType.debt),
    ('Ma',500,EntryType.debt),('Rajib',250,EntryType.debt),('Rajib',500,EntryType.debt),
    ('Boro vhai',1500,EntryType.debt),('Shawon',4500,EntryType.debt),('Nasim mobile',15000,EntryType.debt),
    ('Net bill',525,EntryType.debt),('Current bill',500,EntryType.debt),('Barir current bill',3000,EntryType.debt),
    ('Barir net bill',525,EntryType.debt),('Nasim dhar new',50000,EntryType.debt),
    ('Nasim dhar old',50000,EntryType.debt),('Lalon',10000,EntryType.debt),
    ('Separate loan',95000,EntryType.loan),
  ];
  static const total = 342820;
  static Future<void> importOnce() async {
    final store=LocalStore.instance;
    if(await store.getSetting('initial_debt_seed_imported')=='yes') {
      throw Exception('প্রাথমিক ঋণের তালিকা আগে একবার যোগ করা হয়েছে।');
    }
    final now=DateTime(2026,11,2);
    for(var i=0;i<records.length;i++) {
      final r=records[i];
      await store.add(LedgerEntry(uuid:'initial-debt-${i+1}',title:r.$1,person:r.$1,
        amount:r.$2,type:r.$3,date:now,note:'প্রাথমিক বকেয়া তালিকা থেকে আমদানি',
        category:r.$1=='Basa vara'||r.$1=='Bow'?'পরিবার':(r.$1.contains('bill')||r.$1=='Net bill'||r.$1=='Current bill'?'বিল':'ঋণ')));
    }
    await store.setSetting('initial_debt_seed_imported','yes');
  }
}
