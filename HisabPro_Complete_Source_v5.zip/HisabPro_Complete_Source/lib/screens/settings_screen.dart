import 'package:flutter/material.dart';
import '../config.dart';
import '../services/backup_service.dart';
import '../services/cloud_sync.dart';
import '../services/data_export.dart';
import '../services/initial_debt_seed.dart';

class SettingsScreen extends StatefulWidget {
  final VoidCallback onTheme;
  const SettingsScreen({super.key, required this.onTheme});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool busy = false;
  String status = 'Offline mode';
  Future<void> _run(Future<void> Function() action) async {
    setState(() => busy = true);
    try { await action(); }
    catch (e) { if (mounted) setState(() => status = 'সমস্যা: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> _auth({required bool signUp}) async {
    if (!CloudSync.available) { setState(() => status = 'Supabase URL ও anon key configure করা হয়নি।'); return; }
    final email = TextEditingController();
    final pass = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: Text(signUp ? 'নতুন Cloud Account' : 'Supabase Login'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ইমেইল')),
        TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(signUp ? 'Account তৈরি' : 'Login'))],
    ));
    if (ok != true) { email.dispose(); pass.dispose(); return; }
    await _run(() async {
      if (signUp) {
        final r = await CloudSync.client.auth.signUp(email: email.text.trim(), password: pass.text);
        setState(() => status = r.session == null ? 'Account তৈরি হয়েছে। ইমেইল confirm করে Login করুন।' : 'Account তৈরি ও Login হয়েছে।');
      } else {
        await CloudSync.client.auth.signInWithPassword(email: email.text.trim(), password: pass.text);
        setState(() => status = 'Signed in: ${CloudSync.client.auth.currentUser?.email}');
      }
    });
    email.dispose(); pass.dispose();
  }

  Future<void> _sync() => _run(() async {
    final count = await CloudSync.sync();
    setState(() => status = 'Sync সম্পন্ন। $countটি স্থানীয় পরিবর্তন upload হয়েছে।');
  });

  Future<void> _restore() async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Backup Restore করবেন?'),
      content: const Text('Restore করলে বর্তমান ফোনের সব হিসাব ও সেটিংস backup-এর ডেটা দিয়ে প্রতিস্থাপিত হবে। আগে বর্তমান ডেটার Backup নিন।'),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Restore করুন'))],
    ));
    if (ok != true) return;
    await _run(() async {
      final count = await BackupService.restoreBackup();
      if (count > 0) setState(() => status = '$countটি রেকর্ড Restore হয়েছে। Cloud sync করার আগে ডেটা যাচাই করুন।');
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('সেটিংস ও ব্যাকআপ')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(leading: const Icon(Icons.palette_outlined), title: const Text('থিম পরিবর্তন'), subtitle: const Text('Dark / Light'), onTap: widget.onTheme)),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Cloud Backup', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text(status), const SizedBox(height: 12),
        if (CloudSync.available) ...[
          if (!CloudSync.signedIn) ...[
            OutlinedButton.icon(onPressed: busy ? null : () => _auth(signUp: true), icon: const Icon(Icons.person_add), label: const Text('নতুন Cloud Account তৈরি')),
            FilledButton.icon(onPressed: busy ? null : () => _auth(signUp: false), icon: const Icon(Icons.login), label: const Text('Login')),
          ] else ...[
            Text('Account: ${CloudSync.client.auth.currentUser?.email ?? ''}'),
            OutlinedButton.icon(onPressed: busy ? null : () => _run(() async { await CloudSync.client.auth.signOut(); setState(() => status = 'Signed out'); }), icon: const Icon(Icons.logout), label: const Text('Logout')),
            FilledButton.icon(onPressed: busy ? null : _sync, icon: const Icon(Icons.sync), label: Text(busy ? 'Sync হচ্ছে...' : 'এখনই Sync করুন')),
          ],
        ] else const Text('Supabase URL ও Anon Key configure না করা পর্যন্ত অ্যাপ Offline-এ চলবে।'),
      ]))),
      Card(child: ListTile(leading: const Icon(Icons.backup), title: const Text('পূর্ণাঙ্গ Backup Export'), subtitle: const Text('সব হিসাব, deleted record ও settings JSON ফাইলে সংরক্ষণ'), onTap: busy ? null : () => _run(BackupService.exportBackup))),
      Card(child: ListTile(leading: const Icon(Icons.restore), title: const Text('Backup Restore'), subtitle: const Text('আগের HisabPro JSON backup থেকে হিসাব ফিরিয়ে আনুন'), onTap: busy ? null : _restore)),
      const Padding(padding: EdgeInsets.symmetric(horizontal: 12, vertical: 4), child: Text('সতর্কতা: JSON backup encrypted নয়। নিরাপদ স্থানে রাখুন এবং অন্যকে পাঠাবেন না। Restore করলে বর্তমান ডেটা প্রতিস্থাপিত হবে।', style: TextStyle(color: Colors.deepOrange))),
      Card(child: ListTile(leading: const Icon(Icons.playlist_add), title: const Text('প্রাথমিক ঋণের তালিকা যোগ করুন'), subtitle: const Text('২৫টি বকেয়া + আলাদা ৯৫,০০০ টাকার ঋণ; মোট ৳৩,৪২,৮২০'), onTap: busy ? null : () async {
        final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('প্রাথমিক ঋণ যোগ করবেন?'), content: const Text('২৬টি এন্ট্রি যোগ হবে। আগে থেকে যোগ করা থাকলে চাপবেন না।'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('বাতিল')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('যোগ করুন'))]));
        if (ok == true) await _run(() async { await InitialDebtSeed.importOnce(); setState(() => status = 'প্রাথমিক ঋণের তালিকা যোগ হয়েছে।'); });
      })),
      Card(child: ListTile(leading: const Icon(Icons.table_view), title: const Text('CSV Export'), subtitle: const Text('Excel-এ খোলার উপযোগী হিসাব'), onTap: busy ? null : () => _run(DataExport.exportCsv))),
      const Card(child: ListTile(leading: Icon(Icons.lock_outline), title: Text('Privacy'), subtitle: Text('লোকাল SQLite ডেটা; Cloud চালু করলে নিজের Supabase project-এ পাঠানো হবে।'))),
      const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('HisabPro v1.3.0'), subtitle: Text('Offline-first personal finance manager'))),
    ]),
  );
}
