/// Supabase public client configuration for HisabPro.
/// Publishable/anon keys are designed for client apps; RLS is mandatory.
/// Never place a service_role or secret key in this file.
class AppConfig {
  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://dcqmkhvyqkdvtbczggfc.supabase.co',
  );
  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'sb_publishable_epr-22KdRCe5J8kHTWu6Tw_4FttAC69',
  );
  static bool get cloudConfigured =>
      supabaseUrl.startsWith('https://') && supabaseAnonKey.isNotEmpty;
}
