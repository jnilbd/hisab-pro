create table if not exists public.ledger_entries (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 local_id text not null,
 title text not null,
 person text not null default '',
 amount bigint not null check(amount>0),
 type text not null check(type in ('debt','payment','loan','installment','income','expense','phonePurchase','phoneSale')),
 entry_date timestamptz not null,
 note text not null default '',
 category text not null default 'General',
 deleted_at timestamptz,
 updated_at timestamptz not null default now(),
 unique(user_id,local_id)
);
alter table public.ledger_entries add column if not exists deleted_at timestamptz;
alter table public.ledger_entries add column if not exists updated_at timestamptz not null default now();
alter table public.ledger_entries enable row level security;
drop policy if exists "Users manage own ledger" on public.ledger_entries;
create policy "Users manage own ledger" on public.ledger_entries
 for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create index if not exists ledger_user_date_idx on public.ledger_entries(user_id,entry_date desc);
create index if not exists ledger_user_updated_idx on public.ledger_entries(user_id,updated_at desc);
